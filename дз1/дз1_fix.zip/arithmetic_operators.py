x= int(input())
y= int(input())
if 1<=x<=10**10 and 1<=y<=10**10:
    print(x+y)
    print(x-y)
    print(x*y)