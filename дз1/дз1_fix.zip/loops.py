n = int(input())
if 1<=n<=20:
    for i in range(n):
        if i>=0:
            print(i**2)


