n=input()
n=n.split()
print('-'.join(n))

