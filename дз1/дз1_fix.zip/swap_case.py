s=input()
if 0<len(s)<=1000:
        s=s.swapcase()
        print(s)